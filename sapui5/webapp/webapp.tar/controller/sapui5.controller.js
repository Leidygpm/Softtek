sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
	 */
    function (Controller, JSONModel) {
        "use strict";

        function onInit() {
            //vista
            let oView = this.getView();
            //cargar modelo de paises
            let jsonPaisesModel = new JSONModel();
            //cargar json desde un archivo en el local service
            jsonPaisesModel.loadData("./localService/paises.json", false);
            //asociar modelo con la vista
            oView.setModel(jsonPaisesModel, "paisesModel");
        };
        var Main = Controller.extend("lgpm.accounts.controller.sapui5", {});
        Main.prototype.onInit = onInit;

        return Main;
    });
