sap.ui.define([
	"lgpm/accounts/test/unit/controller/sapui5.controller"
], function () {
	"use strict";
});
